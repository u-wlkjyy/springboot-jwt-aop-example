package com.soft.permissondemo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.soft.permissondemo.entity.Permission;

public interface IPermissionService extends IService<Permission> {
} 