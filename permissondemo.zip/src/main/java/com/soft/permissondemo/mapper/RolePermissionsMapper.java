package com.soft.permissondemo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.soft.permissondemo.entity.RolePermissions;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface RolePermissionsMapper extends BaseMapper<RolePermissions> {
} 